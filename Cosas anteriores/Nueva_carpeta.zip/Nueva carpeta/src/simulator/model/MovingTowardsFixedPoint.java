package simulator.model;

import java.util.List;
import simulator.misc.Vector2D;

public class MovingTowardsFixedPoint implements ForceLaws{
	private  double g;
	private Vector2D o;
	
	public MovingTowardsFixedPoint()
	{
		g=9.81;
		o=new Vector2D();
	}
	public MovingTowardsFixedPoint(double g)
	{
		this.g=g;
		o=new Vector2D();
	}
	
	public void apply(List<Body> bs) {
		for (Body b : bs) 
		{
			Vector2D f = new Vector2D(o.minus(b.getPosition()).direction().scale(-g*b.getMass()));
			b.addForce(f);
		}
	}
	

	//aplicacion de una fuerza hacia el centro
	
}
