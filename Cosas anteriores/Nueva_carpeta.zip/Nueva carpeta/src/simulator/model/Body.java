package simulator.model;

import org.json.JSONObject;

import simulator.misc.Vector2D;

public class Body {
	//cuerpobasico
	protected String id;
	protected Vector2D vel;
	protected Vector2D force;
	protected Vector2D pos;
	protected double mass;
	
	public Body(String id,Vector2D v,Vector2D p,double m)
	{
		this.id = id;
		vel = new Vector2D(v);
		force = new Vector2D();
		pos = new Vector2D(p);
		mass = m;
	}
	
	// METODOS
	
	
		public String getId()//devuelve el identificador del cuerpo
		{
			return id;
		}
		public Vector2D getVelocity()//devuelve el vector de velocidad
		{
			return vel;
		}
		public Vector2D getForce()//devuelve el vector de fuerza 
		{
			return force;
		}
		public Vector2D getPosition()//devuelve el vector de posicion
		{
			return pos;
		}
		public double getMass()//devuelve la masa del cuerpo
		{
			return mass;
		}
		void addForce (Vector2D f)//añade la fuerza f al vector de fuerza del cuerpo(usando el plus del Vector2D)
		{
			force=force.plus(f);
		}
		void resetForce()//pone el valor del vector de fuerza a (0,0)
		{
			force=new Vector2D();
		}
		void move(double t)// mueve el cuerpo
		{
			Vector2D accel;
			if(mass==0)accel=new Vector2D();
			else accel=new Vector2D(force.scale(1/mass));
			pos=pos.plus((vel.scale(t)).plus(accel.scale(t*t/2)));
			vel=vel.plus(accel.scale(t));
		}
		public JSONObject getState()//formato JSON
		{
			JSONObject jso=new JSONObject();
			jso.put("id",getId());
			jso.put("m",getMass());
			jso.put("p",getPosition().asJSONArray());
			jso.put("v",getVelocity().asJSONArray());
			jso.put("f",getForce().asJSONArray());
			return jso;
			
		}
		public String toString()//devuelve getState
		{
			return getState().toString();
		}
	
	
	
	
}
