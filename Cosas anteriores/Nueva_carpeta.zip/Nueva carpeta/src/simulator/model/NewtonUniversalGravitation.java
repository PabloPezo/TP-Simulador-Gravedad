package simulator.model;

import java.util.List;

import simulator.misc.Vector2D;

public class NewtonUniversalGravitation implements ForceLaws {

	private final double G;
	
	public NewtonUniversalGravitation()
	{
		G= 6.67E-11;	
	}
	public void apply(List<Body> bs) {
		Vector2D F;
		double f;
		for (Body Bi : bs) {
			F = new Vector2D();
			for (Body Bj : bs) {
				if (Bi != Bj) {
					f = 0;
					if (Bi.getMass() == 0.0) Bi.vel = new Vector2D();
					else {
						f = (G*Bi.getMass()*Bj.getMass())/
								Math.pow(Bi.getPosition().distanceTo(Bj.getPosition()), 2);
						F = F.plus(Bj.getPosition().minus(Bi.getPosition()).direction().scale(f));
					}
				}
			}
			Bi.addForce(F);
		}
	}

	//funcion aplicacion de fuerza 
	
}
