package simulator.factories;

public class BuilderBasedFactory {

}
